#include <zephyr/pm/pm.h>
#include <hal/nrf_gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/bluetooth/bluetooth.h>

int err; 
static uint32_t time, last_time;
static uint32_t button_counter = 0;
int button_tick = 0;
int sleep_flag = 1;
int counter= 1;
// Bluetooth variables
struct bt_le_ext_adv *adv;
struct bt_le_adv_param adv_param = BT_LE_ADV_PARAM_INIT(BT_LE_ADV_OPT_NONE | BT_LE_ADV_OPT_EXT_ADV | BT_LE_ADV_OPT_USE_IDENTITY | BT_LE_ADV_OPT_NO_2M,
                                                        0x30,//corresponds to 48 milliseconds time interval max and min both
                                                        0x30,
                                                        NULL);
struct bt_le_ext_adv_start_param ext_adv_param = BT_LE_EXT_ADV_START_PARAM_INIT(0, 1);
static uint8_t mfg_data[8] = {0};  
static const struct bt_data ad[] = {BT_DATA(BT_DATA_MANUFACTURER_DATA, mfg_data, 8),};
///////////////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

static void set_random_static_address(void)
{
    printk("Starting iBeacon Demo\n");
    bt_addr_le_t addr; // predefined bluetooth address structure
    err = bt_addr_le_from_str("DD:AF:BB:AE:BA:11", "random", &addr); //converts the string to a Bluetooth address structure

    if (err)
    {
        printk("Invalid BT address (err %d)\n", err);
    }

    err = bt_id_create(&addr, NULL);// Create a new bluetooth identity using the address 'addr' and store the return code in 'err'

    if (err < 0)
    {
        printk("Creating new ID failed (err %d)\n", err);
		return;
    }
        printk("Created new address\n"); 
}

/////////////////////////////////////////////////////////////////////////////////

void adv_param_init(void)
{
    int err;
    err = bt_le_ext_adv_create(&adv_param, NULL, &adv);// create condition for extended advertising

    if (err)
    {
        printk("Failed to create advertising set (err %d)\n", err);
        return;
    }
        printk("Created extended advertising set \n");
}

/////////////////////////////////////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

void enter_sleep(void)
{
    printk("Entering SYSTEM-OFF mode\n");  // Print a message indicating that the device is entering SYSTEM-OFF mode
    NRF_POWER->SYSTEMOFF = 1;  // Set the SYSTEMOFF bit in the NRF_POWER register to enter SYSTEM-OFF mode
}

/////////////////////////////////////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

void start_adv(void)
{

    if (counter)
    {
        counter = counter - 1 ; // decrement the counter by 1
    }
    else
    {
        enter_sleep();  // Enter SYSTEM-OFF mode
    }

    err = bt_le_ext_adv_set_data(adv, ad, ARRAY_SIZE(ad), NULL, 0);  // Set extended advertising data for the advertising instance 'adv' using the advertisement data 'ad' array

    if (err)
    {
        printk("Failed (err %d)\n", err);
        return;
    }

    printk("Start Extended Advertising..."); 
    err = bt_le_ext_adv_start(adv, &ext_adv_param); 

    if (err)
    {
        printk("Failed to start extended advertising (err %d)\n",err);
        return;   // Exit the current function due to the failure in the previous operation
    }

    printk("done.\n"); 
    k_msleep(500);  // delay time 
    bt_le_ext_adv_stop(adv);   // Stop extended advertising for the advertising instance 'adv'
    printk("Stopped advertising..!!\n");   // Print a message indicating that advertising has been stopped
    start_adv();   // Call a function named 'start_adv' to initiate advertising again
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

int j = 0;
void main()
{
    nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led3), gpios));
    nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led3), gpios)); // make pin28 high
    nrf_gpio_cfg_input(DT_GPIO_PIN(DT_NODELABEL(button0), gpios),NRF_GPIO_PIN_PULLUP);// enable button0 as input pin
    nrf_gpio_cfg_sense_set(DT_GPIO_PIN(DT_NODELABEL(button0), gpios),NRF_GPIO_PIN_SENSE_LOW); // Button is 0 when it is pressed.
    int status = nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)); // status variable carries current status of the pin.
    printk("button status=%d\n", status); // status is 0 when button is pressed, and greater than 0 when button is not pressed

    while (nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)) == 0) // return value zero indicates that the button is pressed
    {
    	time = k_uptime_get();

        if (button_counter == 0)
        {
            last_time = time; // will be executed only once.
        }

        if (last_time + 500 == time) // counts 5 seconds since the start of the button press. Change the value to 2000 for 2 seconds long press
        {
            button_counter = 0;
            sleep_flag = 0; // the flag takes the value zero only when the button is pressed continuously for 5 seconds
            printk("Button was pressed continuously for 5 seconds..\n");  // Print a message indicating that the button was pressed continuously for 5 seconds
            printk("last time=%d\n", last_time);  // Print the value of 'last_time' variable
            printk("time=%d\n", time);  // Print the value of 'time' variable

            while (j <= 5) // toggling of led0 is used as an idication that 5 seconds have elapsed since we press the button
            {
                nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // configure led0 as the output pin
                nrf_gpio_pin_toggle(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // toggle the LED
                k_sleep(K_MSEC(50));   // delay time
                j++; // increment the j by 1
            }
            
			break; // when button is pressed continuously for 5 seconds, blink led0. Then come out of the loop, set parameters and start advertising
        }

        button_counter = button_counter + 1;        // increment the button counter by 1
    }

    while (sleep_flag)   // infinite loop
    {
        enter_sleep(); // as long as the sleep flag is 1, stay in deep sleep mode.
    }

    nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // switch off the LED
    mfg_data[0] = 1; // device id
    set_random_static_address();
    err = bt_enable(NULL);    // Enable Bluetooth functionality with default parameters

    if (err)
    {
        printk("Bluetooth init failed (err %d)\n", err);   // print a  message indicating that bluetooth initialization is failed
        return;  
    }

    adv_param_init();  // Initialize advertising parameters
    start_adv();   // Start advertising
}