#ifndef __MAIN_OBSERVER_H__
#define __MAIN_OBSERVER_H__

int init_observer(void);
int observer_start(void);


#endif