
#include <zephyr/kernel.h>   //Library Files needed to run the project
#include <stdio.h>
#include <zephyr/device.h>
#include <hal/nrf_gpio.h>


void main(void)      // main function
{   
        while (1)   //While loop to run the code over and over again
        {   nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // This will switch on 1st led.
            k_sleep(K_MSEC(1000));    //1000 miliSecond delay
           nrf_gpio_pin_clear(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); //switch off 1st led   
           k_sleep(K_MSEC(1000));     //1000 miliSecond delay

		}
}

