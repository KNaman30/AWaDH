
#include <errno.h>  //Library files needed to run the project
#include <string.h>
#define LOG_LEVEL 4
#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(main);
#include <zephyr/kernel.h>
#include <zephyr/zephyr.h>
#include <zephyr/drivers/led_strip.h>
#include <zephyr/device.h>
#include <zephyr/dt-bindings/led/led.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/i2s.h>
#include <zephyr/sys/util.h>

#define STRIP_NODE DT_ALIAS(led_strip)                                  // Define a symbolic name "STRIP_NODE" for the device tree alias "led_strip"                              
#define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)     // Define a symbolic name "STRIP_NUM_PIXELS" for the property "chain_length" of the device tree alias "led_strip"

#define DELAY_TIME K_MSEC(100)                                          // Define a symbolic name "DELAY_TIME" for a delay of 100 milliseconds using the kernel macro K_MSEC()
// #define chain_length 32                             
// Define a macro "RGB" for creating a color with specified red, green, and blue components
#define RGB(_r, _g, _b)                         \
        {                                       \ 
                .r = (_r), .g = (_g), .b = (_b) \                       
        }                                                                 
         
#define LED_GAP 0                                                        // Define the gap between the led's

struct led_rgb pixels[STRIP_NUM_PIXELS];                                 // Define a structure array "pixels" with the type "struct led_rgb" and size determined by the value of "STRIP_NUM_PIXELS"

static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);     // Declare a static constant pointer "strip" and initialize it with the device instance obtained from the device tree alias "led_strip"
                                                                                       
static const struct led_rgb colors[] = {
    RGB(0x2f, 0x00, 0x00), /* red */
    RGB(0x00, 0x1f, 0x00), /* green */
    RGB(0x00, 0x00, 0x2f), /* blue */                                           // Define a static constant array "colors" of structures of type "struct led_rgb
    RGB(0x00, 0x2f, 0x2f), /* cyan */
    RGB(0x2f, 0x00, 0x2f), /* magenta */
    RGB(0x2f, 0x2f, 0x00), /* yellow */
};
size_t cursor = 0, color = 0;             // Initialize variables to track the cursor position and current color index
int rc;                                   // Declaration of integer variable "rc" (potentially used for error codes or return values)
int main(void)                            //  Main function
{

        if (device_is_ready(strip))                         //// Check if the device pointed to by "strip" is ready
        {
                LOG_INF("Found LED strip device %s", strip->name);                  // Log an informational message indicating the discovery of an LED strip device
        } 
       
        while (1)
        {
                int i;
                // memset(&pixels, 0x00, sizeof(pixels));
                for (i = 0; i < 24;)                                             // set the range of the led's in the ring led
                {
                        memcpy(&pixels[i], &colors[color], sizeof(struct led_rgb));         // Copy the color data from the "colors" array to the "pixels" array at index "i"   // using the size of the structure "struct led_rgb"
                        i = i + 1 + LED_GAP;                                                 // Increment the index "i" by 1 and the LED_GAP value
                        k_msleep(100);                                                       // delay time

                led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);                   // Update the RGB values of the LED strip with the data from the "pixels" array  // using the device function "led_strip_update_rgb"
                }

                cursor = cursor + 24;                                                   // Increment the cursor position by 24 (assuming each pixel has 24 bits of data)

                if (cursor >= STRIP_NUM_PIXELS)                                         // Check if the cursor position exceeds or equals the total number of pixels in the LED strip
                {

                        cursor = 0;                                                         // Reset the cursor position to the beginning
                        color++;                                                              // Increment the color index to switch to the next color in the array
                        if (color == ARRAY_SIZE(colors))                                      // Check if all colors in the array have been used
                        {
                                color = 0;                                                     // Reset the color index to start from the beginning of the colors array
                        }
                }

                k_sleep(DELAY_TIME);                // delay time
        }
        return 0;
}