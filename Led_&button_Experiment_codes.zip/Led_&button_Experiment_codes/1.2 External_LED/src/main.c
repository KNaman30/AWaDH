#include <zephyr/zephyr.h>         //Library files needed to run the project
#include <zephyr/drivers/gpio.h>
#include <zephyr/device.h>
#include <hal/nrf_gpio.h>

void main(void) // main function
{
	while (1) {   //While loop to run the code over and over again
		nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led0), gpios));// // configure the pin as output pin// generally pin 0.17 is configured 
                                                                            //but you can change in .dts file //"gpios = <&gpio0 17 GPIO_ACTIVE_LOW>;" in this line
		nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // Switch on the External LED
		k_sleep(K_MSEC(1000));  //1000 miliSecond delay

		nrf_gpio_pin_clear(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // Switch off the External LED
		k_sleep(K_MSEC(1000));  //1000 miliSecond delay
	}
}