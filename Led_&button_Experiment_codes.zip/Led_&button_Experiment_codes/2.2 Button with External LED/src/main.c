
#include <zephyr/kernel.h>   //Library files needed to run the project
#include <zephyr/device.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/sys/util.h> 
#include <zephyr/sys/printk.h>
#include <inttypes.h> 
                      

#define SLEEP_TIME_MS	1

/*
 * Get button configuration from the devicetree sw0 alias. This is mandatory.
 */
#define SW0_NODE	DT_ALIAS(sw0) // Define a macro to access the devicetree node for the 'sw0' alias
#if !DT_NODE_HAS_STATUS(SW0_NODE, okay)// Check if the SW0 node in the device tree has the status "okay
#error "Unsupported board: sw0 devicetree alias is not defined"
#endif
static const struct gpio_dt_spec button = GPIO_DT_SPEC_GET_OR(SW0_NODE, gpios,
							      {0});
static struct gpio_callback button_cb_data;

/*
 * The led1 devicetree alias is optional. If present, we'll use it
 * to turn on the LED whenever the button is pressed.
 */
static struct gpio_dt_spec led = GPIO_DT_SPEC_GET_OR(DT_ALIAS(led1), gpios,
						     {0});// here you chnage your gpio

// Callback function called when the button is pressed
void button_pressed(const struct device *dev, struct gpio_callback *cb,
		    uint32_t pins)
{
	printk("Button pressed at %" PRIu32 "\n", k_cycle_get_32()); // Print a message indicating that the button was pressed
}

int main(void)
{
	int ret;

	// Check if button GPIO is ready
	if (!gpio_is_ready_dt(&button)) {
		printk("Error: button device %s is not ready\n",
		       button.port->name);
		return 0;
	}

	// Configure button GPIO pin as input
	ret = gpio_pin_configure_dt(&button, GPIO_INPUT);
	if (ret != 0) {
		printk("Error %d: failed to configure %s pin %d\n",
		       ret, button.port->name, button.pin);
		return 0;
	}

	// Configure button GPIO pin interrupt
	ret = gpio_pin_interrupt_configure_dt(&button,
					      GPIO_INT_EDGE_TO_ACTIVE);// Configure button GPIO pin interrupt to trigger on the rising edge (button press)
	if (ret != 0) {
		printk("Error %d: failed to configure interrupt on %s pin %d\n",
			ret, button.port->name, button.pin);
		return 0;
	}

	// Initialize button GPIO callback
	gpio_init_callback(&button_cb_data, button_pressed, BIT(button.pin));// Initialize a GPIO callback structure for handling button presses
	gpio_add_callback(button.port, &button_cb_data);// Add the button callback to the GPIO port
	printk("Set up button at %s pin %d\n", button.port->name, button.pin);// Print a message indicating successful setup of the button

	// Check if LED GPIO is ready
	if (led.port && !gpio_is_ready_dt(&led)) {
		printk("Error %d: LED device %s is not ready; ignoring it\n",
		       ret, led.port->name);
		led.port = NULL;
	}
	if (led.port) {
		// Configure LED GPIO pin as output
		ret = gpio_pin_configure_dt(&led, GPIO_OUTPUT);
		if (ret != 0) {
			printk("Error %d: failed to configure LED device %s pin %d\n",
			       ret, led.port->name, led.pin);
			led.port = NULL;
		} else {
			printk("Set up LED at %s pin %d\n", led.port->name, led.pin);
		}
	}

	printk("Press the button\n");
	if (led.port) {
		while (1) {
			/* If we have an LED, match its state to the button's. */
			int val = gpio_pin_get_dt(&button);// Read the current state of the button GPIO pin

			if (val >= 0) {
				gpio_pin_set_dt(&led, val); // Set the LED pin state to match the button state
			}
			k_msleep(SLEEP_TIME_MS);// Delay execution for SLEEP_TIME_MS milliseconds
		}
	}
	return 0;
}
