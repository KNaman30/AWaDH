
#include <errno.h>
#include <string.h>

#define LOG_LEVEL 4
#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(main);

#include <zephyr/kernel.h>
#include <zephyr/zephyr.h>
#include <zephyr/drivers/led_strip.h>
#include <zephyr/device.h>
#include <zephyr/dt-bindings/led/led.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/i2s.h>
#include <zephyr/sys/util.h>

#define STRIP_NODE DT_ALIAS(led_strip)
#define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)

#define DELAY_TIME K_MSEC(50)
// #define chain_length 32

#define RGB(_r, _g, _b)                         \
        {                                       \
                .r = (_r), .g = (_g), .b = (_b) \
        }

#define LED_GAP 0

struct led_rgb pixels[STRIP_NUM_PIXELS];

// int brightness = 0;

static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);

static const struct led_rgb colors[] = {
    RGB(0x2f, 0x00, 0x00), /* red */
    RGB(0x00, 0x1f, 0x00), /* green */
    RGB(0x00, 0x00, 0x2f), /* blue */
    RGB(0x00, 0x2f, 0x2f), /* cyan */
    RGB(0x2f, 0x00, 0x2f), /* magenta */
    RGB(0x2f, 0x2f, 0x00), /* yellow */
};
int main(void)
{
size_t cursor = 0, color = 0;

        if (device_is_ready(strip))
        {
                LOG_INF("Found LED strip device %s", strip->name);
        }

        while (1)

        {
                memset(&pixels, 0x00, sizeof(pixels));
                for (int i = 0; i < 24;)
                {
                        memcpy(&pixels[i], &colors[color], sizeof(struct led_rgb));
                        {
                                i = i + 1 + LED_GAP;
                        }

                        led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);

                        cursor++;

                        if (cursor <= STRIP_NUM_PIXELS )
                        {
                                cursor=0;
                                color++;
                                if (color == ARRAY_SIZE(colors))
                                {
                                        color = 0;
                                }
                        }
                        if(i==23)i=0;

                        k_sleep(DELAY_TIME);
                }
                return 0;
        }
}

/////////////////////////////////////////////////////

/*brightness with color changing*/

// #include <errno.h>
// #include <string.h>

// #define LOG_LEVEL 4
// #include <zephyr/logging/log.h>
// LOG_MODULE_REGISTER(main);

// #include <zephyr/kernel.h>
// #include <zephyr/zephyr.h>
// #include <zephyr/drivers/led_strip.h>
// #include <zephyr/device.h>
// #include <zephyr/dt-bindings/led/led.h>
// #include <zephyr/drivers/gpio.h>
// #include <zephyr/drivers/i2s.h>
// #include <zephyr/sys/util.h>

// #define STRIP_NODE DT_ALIAS(led_strip)
// #define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)

// #define DELAY_TIME K_MSEC(500)
// // #define chain_length 32

// #define RGB(_r, _g, _b)                         \
//         {                                       \
//                 .r = (_r), .g = (_g), .b = (_b) \
//         }

// #define LED_GAP 0

// struct led_rgb pixels[STRIP_NUM_PIXELS];

// int brightness = 0;
// int color_index = 0;

// static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);

// static const struct led_rgb colors[] = {
//     RGB(0x2f, 0x00, 0x00), /* red */
//     RGB(0x00, 0x1f, 0x00), /* green */
//     RGB(0x00, 0x00, 0x2f), /* blue */
//     RGB(0x00, 0x2f, 0x2f), /* cyan */
//     RGB(0x2f, 0x00, 0x2f), /* magenta */
//     RGB(0x2f, 0x2f, 0x00), /* yellow */
// };
// size_t cursor = 0, color = 0;
// int rc;
// int main(void)
// {

//         if (device_is_ready(strip))
//         {
//                 LOG_INF("Found LED strip device %s", strip->name);
//         }
//         while (1)
//         {
//                 // Change color gradually
//                 for (int c = 0; c < sizeof(colors) / sizeof(colors[0]); c++)
//                 {
//                         struct led_rgb start_color = colors[color_index];
//                         struct led_rgb end_color = colors[(color_index + 1) % (sizeof(colors) / sizeof(colors[0]))];

//                         // Interpolate between start and end color
//                         for (int val = 0; val <= 255; val++)
//                         {
//                                 for (int i = 0; i < STRIP_NUM_PIXELS; i++)
//                                 {
//                                         pixels[i].r = start_color.r + (val * (end_color.r - start_color.r)) / 255;
//                                         pixels[i].g = start_color.g + (val * (end_color.g - start_color.g)) / 255;
//                                         pixels[i].b = start_color.b + (val * (end_color.b - start_color.b)) / 255;
//                                 }
//                                 // Update LED strip with current color
//                                 led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);
//                                 k_msleep(5); // Adjust the delay as needed for desired speed
//                         }

//                         color_index = (color_index + 1) % (sizeof(colors) / sizeof(colors[0]));
//                 }
//         }

//         return 0;
// }

////////////////////////////////////////////////////////////////////
/* Creating a patern in ring*/

// #include <errno.h>
// #include <string.h>

// #define LOG_LEVEL 4
// #include <zephyr/logging/log.h>
// LOG_MODULE_REGISTER(main);

// #include <zephyr/kernel.h>
// #include <zephyr/zephyr.h>
// #include <zephyr/drivers/led_strip.h>
// #include <zephyr/device.h>
// #include <zephyr/dt-bindings/led/led.h>
// #include <zephyr/drivers/gpio.h>
// #include <zephyr/drivers/i2s.h>
// #include <zephyr/sys/util.h>

// #define STRIP_NODE DT_ALIAS(led_strip)
// #define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)

// #define DELAY_TIME K_MSEC(50)
// // #define chain_length 32

// #define RGB(_r, _g, _b)                         \
//         {                                       \
//                 .r = (_r), .g = (_g), .b = (_b) \
//         }

// #define LED_GAP 0

// struct led_rgb pixels[STRIP_NUM_PIXELS];

// static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);

// static const struct led_rgb colors[] = {
//     RGB(0x2f, 0x00, 0x00), /* red */
//     RGB(0x00, 0x1f, 0x00), /* green */
//     RGB(0x00, 0x00, 0x2f), /* blue */
//     RGB(0x00, 0x2f, 0x2f), /* cyan */
//     RGB(0x2f, 0x00, 0x2f), /* magenta */
//     RGB(0x2f, 0x2f, 0x00), /* yellow */
// };
// size_t cursor = 0, color = 0;
// int rc;
// int main(void)
// {

//         if (device_is_ready(strip))
//         {
//                 LOG_INF("Found LED strip device %s", strip->name);
//         }

//         while (1)
//         {
//                 memset(&pixels, 0x00, sizeof(pixels));
//                 for (int i = 0; i <= 24;)
//                 {
//                         memcpy(&pixels[i], &colors[color], sizeof(struct led_rgb));
//                         i = i + 1 + LED_GAP;
//                 }

//                 led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);

//                 cursor++;

//                          if (cursor >= STRIP_NUM_PIXELS)
//                 {
//                         cursor = 0;
//                         color++;
//                         if (color == ARRAY_SIZE(colors))
//                         {
//                                 color = 0;
//                         }
//                 }

//                 k_sleep(DELAY_TIME);
//         }
//         return 0;
// }

/////////////////////////////////////////////////////

/* Breathing Effect*/

// #include <errno.h>
// #include <string.h>

// #define LOG_LEVEL 4
// #include <zephyr/logging/log.h>
// LOG_MODULE_REGISTER(main);

// #include <zephyr/kernel.h>
// #include <zephyr/zephyr.h>
// #include <zephyr/drivers/led_strip.h>
// #include <zephyr/device.h>
// #include <zephyr/dt-bindings/led/led.h>
// #include <zephyr/drivers/gpio.h>
// #include <zephyr/drivers/i2s.h>
// #include <zephyr/sys/util.h>

// #define STRIP_NODE DT_ALIAS(led_strip)
// #define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)

// #define DELAY_TIME K_MSEC(50)
// // #define chain_length 32

// #define RGB(_r, _g, _b)                         \
//         {                                       \
//                 .r = (_r), .g = (_g), .b = (_b) \
//         }

// #define LED_GAP 0

// struct led_rgb pixels[STRIP_NUM_PIXELS];

// static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);

// static const struct led_rgb colors[] = {
//     RGB(0xff, 0x00, 0x00), /* red */
//     RGB(0x00, 0xff, 0x00), /* green */
//     RGB(0x00, 0x00, 0xff), /* blue */
//     RGB(0x00, 0x2f, 0x2f), /* cyan */
//     RGB(0x2f, 0x00, 0x2f), /* magenta */
//     RGB(0x2f, 0x2f, 0x00), /* yellow */
// };
// size_t cursor = 0, color = 0;
// int rc;
// int main(void)
// {

//         if (device_is_ready(strip))
//         {
//                 LOG_INF("Found LED strip device %s", strip->name);
//         }
//         while (1)
//         {
//                 // Increase brightness
//                 for (int val = 0; val <= 255; val++)
//                 {
//                         for (int i = 0; i < STRIP_NUM_PIXELS; i++)
//                         {
//                                 pixels[i].r = (val * colors[color].r) / 255;
//                                 pixels[i].g = (val * colors[color].g) / 255;
//                                 pixels[i].b = (val * colors[color].b) / 255;
//                         }
//                         // Update LED strip with current brightness
//                         led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);
//                         k_msleep(5); // Adjust the delay as needed for desired speed
//                 }

//                 // Decrease brightness
//                 for (int val = 255; val >= 0; val--)
//                 {
//                         for (int i = 0; i < STRIP_NUM_PIXELS; i++)
//                         {
//                                 pixels[i].r = (val * colors[color].r) / 255;
//                                 pixels[i].g = (val * colors[color].g) / 255;
//                                 pixels[i].b = (val * colors[color].b) / 255;
//                         }
//                         // Update LED strip with current brightness
//                         led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);
//                         k_msleep(5); // Adjust the delay as needed for desired speed
//                 }
//         }

//         return 0;
// }