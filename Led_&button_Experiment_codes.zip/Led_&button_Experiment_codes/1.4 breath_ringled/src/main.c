#include <errno.h>                          //Library files needed to run the project
#include <string.h>                             
#define LOG_LEVEL 4                            
#include <zephyr/logging/log.h>                          
LOG_MODULE_REGISTER(main);                               
#include <zephyr/kernel.h>                              
#include <zephyr/zephyr.h>                                   
#include <zephyr/drivers/led_strip.h>                     
#include <zephyr/device.h>                                 
#include <zephyr/dt-bindings/led/led.h>                      
#include <zephyr/drivers/gpio.h>                              
#include <zephyr/drivers/i2s.h>                               
#include <zephyr/sys/util.h>                                 

#define STRIP_NODE DT_ALIAS(led_strip)                                            // Define a symbolic name "STRIP_NODE" for the device tree alias "led_strip"
#define STRIP_NUM_PIXELS DT_PROP(DT_ALIAS(led_strip), chain_length)                // Define a symbolic name "STRIP_NUM_PIXELS" for the property "chain_length" of the device tree alias "led_strip"

#define DELAY_TIME K_MSEC(50)                                                        // Define a symbolic name "DELAY_TIME" for a delay of 50 milliseconds using the kernel macro K_MSEC()
// #define chain_length 32
// Define a macro "RGB" for creating a color with specified red, green, and blue components

#define RGB(_r, _g, _b)                         \
        {                                       \
                .r = (_r), .g = (_g), .b = (_b) \
        }
 
#define LED_GAP 0                                                                   // (This represents the gap between LEDs, if any

struct led_rgb pixels[STRIP_NUM_PIXELS];                                         // Define an array "pixels" of structures of type "struct led_rgb"      // with the size determined by the value of "STRIP_NUM_PIXELS"
// int brightness = 0;

static const struct device *const strip = DEVICE_DT_GET(STRIP_NODE);                       // Define a static constant pointer "strip" and initialize it with the device instance  // obtained from the device tree alias "led_strip"

// Define a static constant array "colors" of structures of type "struct led_rgb"

static const struct led_rgb colors[] = {
    RGB(0x2f, 0x00, 0x00), /* red */
    RGB(0x00, 0x1f, 0x00), /* green */
    RGB(0x00, 0x00, 0x2f), /* blue */
    RGB(0x00, 0x2f, 0x2f), /* cyan */
    RGB(0x2f, 0x00, 0x2f), /* magenta */
    RGB(0x2f, 0x2f, 0x00), /* yellow */
};
int main(void)                               // main function
{
size_t cursor = 0, color = 0;                                 // Initialize variables to track the cursor position and current color index   // Cursor position  // Current color index

        if (device_is_ready(strip))                           // Check if the LED strip device is ready for operation
        {
                LOG_INF("Found LED strip device %s", strip->name);                // Log an informational message indicating the discovery of the LED strip device
        }

        while (1)

        {
                memset(&pixels, 0x00, sizeof(pixels));                             // Set all elements of the "pixels" array to zero using memset
                for (int i = 0; i < 24;)                                            // set the range og the led's on ring led
                {
                        memcpy(&pixels[i], &colors[color], sizeof(struct led_rgb));                         // Copy the color data from the "colors" array to the "pixels" array at index "i"
                        {   
                                i = i + 1 + LED_GAP;                                                    // Increment the index "i" by 1 and the LED_GAP value
                        } 

                        led_strip_update_rgb(strip, pixels, STRIP_NUM_PIXELS);                       // Update the RGB values of the LED strip using the data from the "pixels" array

                        cursor++;                                                                       // Increment the cursor to move to the next position

                        if (cursor <= STRIP_NUM_PIXELS )                                                   // Check if the cursor is within the bounds of the LED strip length
                        {
                                cursor=0;                                                                     // Reset the cursor to the beginning
                                color++;                                                                           // Increment the color index to switch to the next color in the array
                                if (color == ARRAY_SIZE(colors))                                  // If all colors have been used, reset the color index to start from the beginning
                                {
                                        color = 0;                                        // Reset the color index to start from the beginning of the colors array
                                }
                        } 
                        if(i==23)i=0;                                                       // Reset the index "i" to 0 if it reaches 23 (assuming it represents the last LED)

                        k_sleep(DELAY_TIME);                                             // delay time
                }
                return 0;
        }
}

